package com.tsystems.e2ee.android;

import com.tsystems.e2ee.crypto1.CryptographyException;
import com.tsystems.e2ee.crypto1.local.identity.IdentityHolder;
import com.tsystems.e2ee.crypto1.local.identity.X509Identity;
import org.junit.Before;

import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.UUID;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {


  public static final String TESTDATA = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor"
      + " incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco"
      + " laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit"
      + " esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa"
      + " qui officia deserunt mollit anim id est laborum.";
  public static final String TESTID = UUID.randomUUID().toString();
  
  private String localEntityName = "patient";
  private String[] remoteEntityName = { "physician" }; // eve has no identity

  final static String pfxPath = "CA/intermediate/private/";

  final static char[] PASSWORD_FOR_ALL = "changeit".toCharArray();

  @Before
  public void setup()
      throws IOException, CryptographyException, KeyStoreException, CertificateException, NoSuchAlgorithmException,
      UnrecoverableKeyException {
    KeyStore ksEncryption = KeyStore.getInstance("PKCS12");
    ksEncryption.load(ClassLoader.getSystemResourceAsStream(pfxPath+localEntityName+".pfx"), PASSWORD_FOR_ALL);

    KeyStore ksSignature = KeyStore.getInstance("PKCS12");
    ksSignature.load(ClassLoader.getSystemResourceAsStream(localEntityName), PASSWORD_FOR_ALL);

    X509Certificate encryptionCertificate = (X509Certificate)ksEncryption.getCertificate(localEntityName);
    X509Certificate signatureCertificate = (X509Certificate)ksSignature.getCertificate(localEntityName);
    KeyPair encryptionKeyPair = new KeyPair(
        encryptionCertificate.getPublicKey(),
        (PrivateKey) ksEncryption.getKey(localEntityName, PASSWORD_FOR_ALL));
    KeyPair signatureKeyPair = new KeyPair(
        signatureCertificate.getPublicKey(),
        (PrivateKey) ksSignature.getKey(localEntityName, PASSWORD_FOR_ALL));

    IdentityHolder identityHolder=  new X509Identity(
        localEntityName,
        encryptionCertificate,
        encryptionKeyPair,
        signatureCertificate,
        signatureKeyPair
    );
  }

}