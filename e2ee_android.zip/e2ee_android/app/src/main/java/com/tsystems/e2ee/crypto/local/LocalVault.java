/*
 * Copyright (c) 2018 T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, D-01129 Dresden, Germany
 * All rights reserved.
 *
 * Autor: yuti
 * Datum: 18/11/2018
 */
package com.tsystems.e2ee.crypto.local;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.security.PrivateKey;
import java.security.PublicKey;

@Entity(tableName = "local_vault")
public class LocalVault {

  @PrimaryKey
  private int id;

  @ColumnInfo(name = "afgh_init_parameter")
  private String afghInitParametersString;




  /**
   * AFGH key pair pkE, skE todo: maynot need to be stored
   */
  private byte[] afghPrivateKey;

  private byte[] afghPublicKey;

  /**
   * DEK' = AFGH2(DEK, pkE)
   */
  @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
  private byte[] vaultEncryptedCryptionKey;

  @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
  private byte[] vaultEncryptedSecretKey;
}
