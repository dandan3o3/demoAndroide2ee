/*
 * Copyright (c) 2018 T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, D-01129 Dresden, Germany
 * All rights reserved.
 *
 * Autor: yuti
 * Datum: 18/11/2018
 */
package com.tsystems.e2ee.crypto.local;

import com.tsystems.e2ee.crypto.common.VaultCryptoConfiguration;

import java.security.Key;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;

public class Identity {

  /**
   * Encryption Key pair
   */
  private KeyPair encryptionKeyPair;

  /**
   * Signature Key Pair
   */
  private KeyPair signatureKeyPair;


}
