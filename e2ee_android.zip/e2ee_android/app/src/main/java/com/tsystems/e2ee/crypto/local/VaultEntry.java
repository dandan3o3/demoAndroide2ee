/*
 * Copyright (c) 2018 T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, D-01129 Dresden, Germany
 * All rights reserved.
 *
 * Autor: yuti
 * Datum: 18/11/2018
 */
package com.tsystems.e2ee.crypto.local;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "vault_entry")
public class VaultEntry {

  @PrimaryKey
  private int id;
}
