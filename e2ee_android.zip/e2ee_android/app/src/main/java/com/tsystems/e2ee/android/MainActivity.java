package com.tsystems.e2ee.android;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
//
//  private RemoteAddressBookStorageMock remoteAddressBookStorageMock;
//  private LocalEntityStorageMock localEntityStorageMock;
//  private LocalEntityStorageMock remoteEntityStorageMockPhysician;
//  private LocalEntityStorageMock remoteEntityStorageMockDeputy;
//  private HashMap<String, LocalEntityStorageMock> entityStorageMockHashMap = new HashMap<>();
//
//  private List<VaultEntryListItem> vaultEntries = new ArrayList<>();
//  private List<String> permissions = new ArrayList<>();
//  private List<VaultEntryListItem> physicianEntries = new ArrayList<>();
//  private List<VaultEntryListItem> deputyEntries = new ArrayList<>();
//
//  private String localEntity = "patient";
//  private String remoteEntityPhysician = "physician";
//  private String remoteEntityDeputy = "deputy";
//
//  @Override
//  protected void onCreate(Bundle savedInstanceState) {
//    super.onCreate(savedInstanceState);
//    setContentView(R.layout.demo_main);
//    initialMockStorage();
//
//    final ListView localVaultEntryListView = (ListView) findViewById(R.id.localVaultList);
//    final ListView localpermissionsListView = (ListView) findViewById(R.id.localPermissionList);
//    final ListView physicianEntriesListView = (ListView) findViewById(R.id.physicianVaultEntryList);
//    final ListView deputyEntriesListView = (ListView) findViewById(R.id.deputyVaultEntryList);
//
//
//    final ArrayAdapter<String> adapterPermissions = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,permissions);
//    final ArrayAdapter<VaultEntryListItem> adapterlocalVaultEntry = new VaultEntryAdapter(this,vaultEntries);
//    final ArrayAdapter<VaultEntryListItem> adapterphysicianEntries = new VaultEntryAdapter(this,physicianEntries);
//    final ArrayAdapter<VaultEntryListItem> adapterdeputyEntries = new VaultEntryAdapter(this,deputyEntries);
//
//    localpermissionsListView.setAdapter(adapterPermissions);
//    localVaultEntryListView.setAdapter(adapterlocalVaultEntry);
//    physicianEntriesListView.setAdapter(adapterphysicianEntries);
//    deputyEntriesListView.setAdapter(adapterdeputyEntries);
//
//    final Button btnClearPermissions = findViewById(R.id.clearPermissions);
//    btnClearPermissions.setOnClickListener(new View.OnClickListener() {
//      @Override
//      public void onClick(View v) {
//        clearPermissions();
//        updatePermissionsData();
//        adapterPermissions.notifyDataSetChanged();
//      }
//    });
//
//    final Button btnShareVaultPhysician = findViewById(R.id.shareVaultPhysician);
//    btnShareVaultPhysician.setOnClickListener(new View.OnClickListener() {
//      @Override
//      public void onClick(View v) {
//        sendShareVaultRequest(remoteEntityStorageMockPhysician);
//        updatePermissionsData();
//        updatePhysicianData();
//        adapterphysicianEntries.notifyDataSetChanged();
//        adapterPermissions.notifyDataSetChanged();
//      }
//    });
//
//    final Button btnShareVaultDeputy =  findViewById(R.id.shareVaultDeputy);
//    btnShareVaultDeputy.setOnClickListener(new View.OnClickListener() {
//      @Override
//      public void onClick(View v) {
//        sendShareVaultRequest(remoteEntityStorageMockDeputy);
//        updatePermissionsData();
//        updateDeputyData();
//        adapterdeputyEntries.notifyDataSetChanged();
//        adapterPermissions.notifyDataSetChanged();
//      }
//    });
//
//    final Button btnGetVaultPhysician = findViewById(R.id.GetVaultPhysician);
//    btnGetVaultPhysician.setOnClickListener(new View.OnClickListener() {
//      @Override
//      public void onClick(View v) {
//        updatePhysicianData();
//        adapterphysicianEntries.notifyDataSetChanged();
//      }
//    });
//
//    final Button btnGetVaultDeputy =  findViewById(R.id.GetVaultDeputy);
//    btnGetVaultDeputy.setOnClickListener(new View.OnClickListener() {
//      @Override
//      public void onClick(View v) {
//        updateDeputyData();
//        adapterdeputyEntries.notifyDataSetChanged();
//      }
//    });
//
//    final EditText idText = findViewById(R.id.editId);
//    final EditText idMessage = findViewById(R.id.editMessage);
//
//    final Button btnAddVaultEntry =  findViewById(R.id.addEntryButton);
//    btnAddVaultEntry.setOnClickListener(new View.OnClickListener() {
//      @Override
//      public void onClick(View v) {
//        if(idText.getText().toString().isEmpty()||idMessage.getText().toString().isEmpty()){
//          return;
//        }
//          addEntry(idText.getText().toString(), idMessage.getText().toString());
//          updateLocalData();
//          adapterlocalVaultEntry.notifyDataSetChanged();
//      }
//    });
//
//
//  }
//
//  void addEntry(String id, String message){
//    try {
//      localEntityStorageMock.getLocalVault()
//          .addEntry(id
//              , message.getBytes()
//              ,localEntityStorageMock.getEntityIdentity()
//              , localEntityStorageMock.getX509Identity().getSigner(localEntityStorageMock.getVault().getCryptoConfiguration()));
//    } catch (CryptographyException e) {
//      e.printStackTrace();
//    }
//  }
//
//  void initialMockStorage() {
//    remoteAddressBookStorageMock = new RemoteAddressBookStorageMock(getApplicationContext());
//    localEntityStorageMock = new LocalEntityStorageMock(localEntity,getApplicationContext());
//    remoteEntityStorageMockDeputy = new LocalEntityStorageMock(remoteEntityDeputy,getApplicationContext());
//    remoteEntityStorageMockPhysician = new LocalEntityStorageMock(remoteEntityPhysician,getApplicationContext());
//  }
//
//  void updateLocalData(){
//    vaultEntries.clear();
//    for(String entryId: localEntityStorageMock.getLocalVault().getEntryIds()){
//      VaultEntry vaultEntry = localEntityStorageMock.getLocalVault().getEntry(entryId);
//      try {
//        vaultEntries.add(new VaultEntryListItem(entryId,new String(vaultEntry.getEncryptedMessage(), "UTF-8")));
//      } catch (UnsupportedEncodingException e) {
//        e.printStackTrace();
//      }
//    }
//  }
//
//  void clearPermissions(){
//    for(Identity identity: localEntityStorageMock.getLocalVault().getPermittedIdentities()){
//      try {
//        localEntityStorageMock.getLocalVault().removePermission(identity,localEntityStorageMock.getX509Identity().getDecryptor());
//      } catch (CryptographyException e) {
//        e.printStackTrace();
//      }
//    }
//  }
//
//  void updatePhysicianData() {
//    physicianEntries.clear();
//    for(String entryId: localEntityStorageMock.getLocalVault().getEntryIds()){
//
//      GetVaultRequest getVaultRequest = new GetVaultRequest(remoteEntityStorageMockPhysician.getEntityIdentity(),entryId);
//      GetVaultResponse response = getVaultRequest.sendMock(localEntityStorageMock);
//      if(response!=null){
//        try {
//          byte[] data =response.responseToDescriptedDataBytes(remoteEntityStorageMockPhysician.getX509Identity().getDecryptor());
//          physicianEntries.add(new VaultEntryListItem(entryId,new String(data, "UTF-8")));
//        } catch (CryptographyException e) {
//          e.printStackTrace();
//        } catch (UnsupportedEncodingException e) {
//          e.printStackTrace();
//        }
//      }
//    }
//  }
//
//  void updateDeputyData(){
//    deputyEntries.clear();
//    for(String entryId: localEntityStorageMock.getLocalVault().getEntryIds()){
//      GetVaultRequest getVaultRequest = new GetVaultRequest(remoteEntityStorageMockDeputy.getEntityIdentity(),entryId);
//      GetVaultResponse response = getVaultRequest.sendMock(localEntityStorageMock);
//      if(response!=null){
//        try {
//          byte[] data =response.responseToDescriptedDataBytes(remoteEntityStorageMockDeputy.getX509Identity().getDecryptor());
//          deputyEntries.add(new VaultEntryListItem(entryId,new String(data, "UTF-8")));
//        } catch (CryptographyException e) {
//          e.printStackTrace();
//        } catch (UnsupportedEncodingException e) {
//          e.printStackTrace();
//        }
//      }
//    }
//  }
//
//  void updatePermissionsData(){
//    permissions.clear();
//    for(Identity identity: localEntityStorageMock.getVault().getPermittedIdentities()){
//      permissions.add(identity.getName());
//    }
//  }
//
//  void sendShareVaultRequest(LocalEntityStorageMock storageMock){
//    ShareVaultRequest request = new ShareVaultRequest(storageMock.getEntityIdentity());
//    request.sendMock(localEntityStorageMock,remoteAddressBookStorageMock);
//  }
}
