package com.tsystems.e2ee.android.model;

/*
 * Copyright (c) 2018 T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, D-01129 Dresden, Germany
 * All rights reserved.
 *
 * Autor: yuti
 * Datum: 17/10/2018
 */
public class VaultEntryListItem {

  private String entryId;
  private String message;

  public String getEntryId() {
    return entryId;
  }

  public void setEntryId(String entryId) {
    this.entryId = entryId;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public VaultEntryListItem(String entryId, String message) {
    this.entryId = entryId;
    this.message = message;
  }
}
