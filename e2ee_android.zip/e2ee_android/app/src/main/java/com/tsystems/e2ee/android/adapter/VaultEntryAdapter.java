package com.tsystems.e2ee.android.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.tsystems.e2ee.android.R;
import com.tsystems.e2ee.android.model.VaultEntryListItem;

import java.util.ArrayList;
import java.util.List;

/*
 * Copyright (c) 2018 T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, D-01129 Dresden, Germany
 * All rights reserved.
 *
 * Autor: yuti
 * Datum: 17/10/2018
 */
public class VaultEntryAdapter extends ArrayAdapter<VaultEntryListItem> {

  private Context context;
  private List<VaultEntryListItem> items = new ArrayList<>();

  public VaultEntryAdapter(@NonNull Context context,
      @NonNull List<VaultEntryListItem> objects) {
    super(context, 0, objects);
    this.context = context;
    this.items = objects;
  }

  @NonNull
  @Override
  public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
    View listView = convertView;
    if(listView == null){
      listView = LayoutInflater.from(context).inflate(R.layout.vault_entry_list_item,parent,false);
    }
    VaultEntryListItem item = items.get(position);

    TextView idText = (TextView)listView.findViewById(R.id.textId);
    TextView messageText = (TextView)listView.findViewById(R.id.textMessage);

    idText.setText(item.getEntryId());
    messageText.setText(item.getMessage());

    return listView;
  }
}
