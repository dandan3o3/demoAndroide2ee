package com.tsystems.e2ee.crypto.afgh;

import com.tsystems.e2ee.crypto.CryptographyException;
import com.tsystems.e2ee.crypto.common.VaultCryptoConfiguration;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.HashMap;
import java.util.Map;

public class PublicKeyCipher {

  private static final Map<VaultCryptoConfiguration,PublicKeyCipher> publicKeyCiphers = new HashMap<>();
  private final Cipher cipher;
  private final Signature signGen;
  private final KeyPairGenerator keyPairGenerator;

  public static PublicKeyCipher getInstance(VaultCryptoConfiguration cryptoConfiguration) throws CryptographyException {
    synchronized(publicKeyCiphers) {
      if (!publicKeyCiphers.containsKey(cryptoConfiguration)) {
        publicKeyCiphers.put(cryptoConfiguration, new PublicKeyCipher(cryptoConfiguration));
      }
      return publicKeyCiphers.get(cryptoConfiguration);
    }
  }

  private PublicKeyCipher(VaultCryptoConfiguration cryptoConfiguration) throws CryptographyException {
    try {
      cipher = Cipher.getInstance(
          cryptoConfiguration.getAsymmetricCipherName(),
          cryptoConfiguration.getAsymmetricCipherProvider());

      keyPairGenerator = KeyPairGenerator.getInstance(
          cryptoConfiguration.getKeyPairGeneratorName(),
          cryptoConfiguration.getKeyPairGeneratorProvider());

      keyPairGenerator.initialize(cryptoConfiguration.getAsymmetricKeyLength());

      signGen = Signature.getInstance(
          cryptoConfiguration.getSignatureName(),
          cryptoConfiguration.getSignatureProvider());

    } catch (NoSuchAlgorithmException|NoSuchProviderException|NoSuchPaddingException e) {
      throw new CryptographyException(e.getMessage(), e);
    }
  }

  public synchronized byte[] encrypt(PublicKey key, byte[] message) throws CryptographyException {
    try {
      cipher.init(Cipher.ENCRYPT_MODE, key);
      return cipher.doFinal(message);
    } catch (IllegalBlockSizeException | BadPaddingException | InvalidKeyException e) {
      throw new CryptographyException(e.getMessage(), e);
    }
  }

  public synchronized byte[] decrypt(PrivateKey key, byte[] message) throws CryptographyException {
    try {
      cipher.init(Cipher.DECRYPT_MODE, key);
      return cipher.doFinal(message);
    } catch (IllegalBlockSizeException | BadPaddingException | InvalidKeyException e) {
      throw new CryptographyException(e.getMessage(), e);
    }
  }

  public byte[] sign(PrivateKey key, byte[]... content) throws CryptographyException {
    try {
      synchronized (signGen) {
        signGen.initSign(key);
        for (byte[] c:content) {
          signGen.update(c);
        }
        return signGen.sign();
      }
    } catch (SignatureException|InvalidKeyException e) {
      throw new CryptographyException(e.getMessage(), e);
    }
  }

  public boolean verify(PublicKey key, byte[] signature, byte[]... content) throws CryptographyException {
    try {
      synchronized (signGen) {
        signGen.initVerify(key);
        for (byte[] c:content) {
          signGen.update(c);
        }
        return signGen.verify(signature);
      }
    } catch (SignatureException|InvalidKeyException e) {
      throw new CryptographyException(e.getMessage(), e);
    }
  }

  public KeyPair generateKeyPair() {
    return keyPairGenerator.generateKeyPair();
  }
}
