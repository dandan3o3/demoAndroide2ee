/*
 * Copyright (c) 2018 T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, D-01129 Dresden, Germany
 * All rights reserved.
 *
 * Autor: yuti
 * Datum: 18/11/2018
 */
package com.tsystems.e2ee.crypto.common;


public class CryptoSharingParameter {

  VaultCryptoConfiguration cryptoConfiguration;

  String afghCryptoParametersInitalString;
}
