package com.tsystems.e2ee.crypto.common;

public final class VaultCryptoConfiguration {
  private String symmetricCipherName = "AES/GCM/NoPadding";
  private String symmetricCipherProvider = "BC";
  private int symmetricKeyLength = 128;

  private String keyGeneratorName = "AES";
  private String keyGeneratorProvider = "BC";

  private String asymmetricCipherName = "RSA";
  private String asymmetricCipherProvider = "BC";
  private int asymmetricKeyLength = 4096;

  private String keyPairGeneratorName = "RSA";
  private String keyPairGeneratorProvider = "BC";

  private String signatureName = "SHA256withRSA";
  private String signatureProvider = "BC";

  public String getSymmetricCipherName() {
    return symmetricCipherName;
  }

  public void setSymmetricCipherName(String symmetricCipherName) {
    this.symmetricCipherName = symmetricCipherName;
  }

  public String getSymmetricCipherProvider() {
    return symmetricCipherProvider;
  }

  public void setSymmetricCipherProvider(String symmetricCipherProvider) {
    this.symmetricCipherProvider = symmetricCipherProvider;
  }

  public String getAsymmetricCipherName() {
    return asymmetricCipherName;
  }

  public void setAsymmetricCipherName(String asymmetricCipherName) {
    this.asymmetricCipherName = asymmetricCipherName;
  }

  public String getAsymmetricCipherProvider() {
    return asymmetricCipherProvider;
  }

  public void setAsymmetricCipherProvider(String asymmetricCipherProvider) {
    this.asymmetricCipherProvider = asymmetricCipherProvider;
  }

  public String getSignatureName() {
    return signatureName;
  }

  public void setSignatureName(String signatureName) {
    this.signatureName = signatureName;
  }

  public String getSignatureProvider() {
    return signatureProvider;
  }

  public void setSignatureProvider(String signatureProvider) {
    this.signatureProvider = signatureProvider;
  }

  public int getSymmetricKeyLength() {
    return symmetricKeyLength;
  }

  public void setSymmetricKeyLength(int symmetricKeyLength) {
    this.symmetricKeyLength = symmetricKeyLength;
  }

  public int getAsymmetricKeyLength() {
    return asymmetricKeyLength;
  }

  public void setAsymmetricKeyLength(int asymmetricKeyLength) {
    this.asymmetricKeyLength = asymmetricKeyLength;
  }

  public String getKeyGeneratorName() {
    return keyGeneratorName;
  }

  public void setKeyGeneratorName(String keyGeneratorName) {
    this.keyGeneratorName = keyGeneratorName;
  }

  public String getKeyGeneratorProvider() {
    return keyGeneratorProvider;
  }

  public void setKeyGeneratorProvider(String keyGeneratorProvider) {
    this.keyGeneratorProvider = keyGeneratorProvider;
  }

  public String getKeyPairGeneratorName() {
    return keyPairGeneratorName;
  }

  public void setKeyPairGeneratorName(String keyPairGeneratorName) {
    this.keyPairGeneratorName = keyPairGeneratorName;
  }

  public String getKeyPairGeneratorProvider() {
    return keyPairGeneratorProvider;
  }

  public void setKeyPairGeneratorProvider(String keyPairGeneratorProvider) {
    this.keyPairGeneratorProvider = keyPairGeneratorProvider;
  }
}
