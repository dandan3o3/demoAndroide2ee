/*
 * Copyright (c) 2018 T-Systems Multimedia Solutions GmbH
 * Riesaer Str. 5, D-01129 Dresden, Germany
 * All rights reserved.
 *
 * Autor: yuti
 * Datum: 11/11/2018
 */

package com.tsystems.e2ee.android;


import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.runner.RunWith;

/**
 * Test class simulate the communication process between alice, proxy server and Bob, including
 * 1. alice create Vault and add to server -> AddVault/ AddVaultEntry
 * 2. bob request for vault parameters  - > GetVaultParams
 * 3. bob request request permission -> requestPermission
 * 4. alice get symmetric key for the message -> GetVaultEntryKey
 * 5. alice grants permission for bob -> generate and send back reencryption key -> requestPermissionResponse
 * 6. bob call getMessage and decrypt it locally -> getMessage
 */
@RunWith(AndroidJUnit4.class)
public class E2eeDemoTest {
//
//  //storage
//  private HashMap<String, LocalEntityStorageMock> entityStorageMockHashMap = new HashMap<>();
//  private LocalEntityStorageMock aliceLocalEntity; //alice
//  private LocalEntityStorageMock bobLocalEntity; //bob has no identity
//
//
//  //test data
//  public static final String TESTDATA = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor"
//      + " incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco"
//      + " laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit"
//      + " esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa"
//      + " qui officia deserunt mollit anim id est laborum.";
//  public static final String TESTID = UUID.randomUUID().toString();
//
//
//
//  //alice
//  private AFGHCryptoParameters alice_params;
//  private String alice_pairing_params_string;// shared across all the entities
//
//
//  //bob
//  private AFGHCryptoParameters bob_params;
//
//  //proxy
//  private AFGHCryptoParameters proxy_params;
//
//  ////////////////////////////// initialization //////////////////////////////////////////////////////
//  void alice_bob_initial_locals(){
//    aliceLocalEntity = new LocalEntityStorageMock("patient", InstrumentationRegistry.getTargetContext());
//    bobLocalEntity = new LocalEntityStorageMock("physician", InstrumentationRegistry.getTargetContext());
//  }
//
//  void Alice_initial_global() {
//    alice_params = new AFGHCryptoParameters(null);
//    alice_pairing_params_string = alice_params.getCurveParams().toString();
//  }
//
//  void bob_initial_global() {
//    if (alice_pairing_params_string != null) {
//      bob_params = generateFromPairingParamterString(alice_pairing_params_string);
//    }
//  }
//
//  void proxy_initial_global() {
//    if (alice_pairing_params_string != null) {
//      proxy_params = generateFromPairingParamterString(alice_pairing_params_string);
//    }
//  }
//////////////////////////////////// vault Creation/////////////////////////////////////////////////////////
//  void createVaultRequest() {
//    //1. create local vault
//
//    //2. add vault to remote
//
//  }
//
//  void addVaultEntryRequest() {
//
//  }
//
//  AFGHCryptoParameters generateFromPairingParamterString(String pairingparamString) {
//    PairingParameters pairingParameters2 = new PropertiesParameters();
//    readFromString(pairingparamString, (PropertiesParameters) pairingParameters2);
//    AFGHCryptoParameters NEW_Afghglobal = new AFGHCryptoParameters(pairingParameters2);
//    return NEW_Afghglobal;
//  }
//
//  // use to share AFGHGlobalParameters across the all the participant party
//  public void readFromString(String inputString, final PropertiesParameters propertiesParameters) {
//    Reader inputStringReader = new StringReader(inputString);
//    BufferedReader reader = new BufferedReader(inputStringReader);
//
//    try {
//      while (true) {
//        String line = reader.readLine();
//        if (line == null) {
//          return;
//        }
//
//        line = line.trim();
//        if (line.length() != 0 && !line.startsWith("#")) {
//          StringTokenizer tokenizer = new StringTokenizer(line, "= :", false);
//          String key = tokenizer.nextToken();
//          String value = tokenizer.nextToken();
//          propertiesParameters.put(key, value);
//        }
//      }
//
//    } catch (IOException var7) {
//      throw new RuntimeException(var7);
//    }
//  }

}
